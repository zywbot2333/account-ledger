<?php
// 站点配置 —— 由安装程序生成于 2026-10-07 22:04

// 数据库连接
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);
define('DB_NAME', '123123');
define('DB_USER', '123123');
define('DB_PASS', '123123');

// 应用
define('APP_NAME', '�˺���֧');
define('APP_DEBUG', false);      // 调试模式（true 时数据库异常会直接抛出）
define('DAILY_REG_LIMIT', 2);   // 每个IP每天最多注册账号数
define('TX_PER_PAGE', 20);      // 流水分页每页条数
